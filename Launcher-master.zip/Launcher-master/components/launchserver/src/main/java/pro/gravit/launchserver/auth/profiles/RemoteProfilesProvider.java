package pro.gravit.launchserver.auth.profiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pro.gravit.launcher.base.Downloader;
import pro.gravit.launcher.base.HttpHelper;
import pro.gravit.launcher.base.profiles.ClientProfile;
import pro.gravit.launcher.base.profiles.ClientProfileBuilder;
import pro.gravit.launcher.base.request.RequestFeatureHttpAPIImpl;
import pro.gravit.launcher.core.hasher.HashedDir;
import pro.gravit.launcher.core.hasher.HashedEntry;
import pro.gravit.launcher.core.hasher.HashedFile;
import pro.gravit.launchserver.command.Command;
import pro.gravit.launchserver.socket.Client;
import pro.gravit.utils.helper.IOHelper;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class RemoteProfilesProvider extends ProfilesProvider {
    private static final Logger log = LoggerFactory.getLogger(RemoteProfilesProvider.class);
    public String baseUrl = "PASTE BASE URL HERE";
    public String accessToken = "PASTE ACCESS TOKEN HERE";
    private final transient HttpClient client = HttpClient.newBuilder().build();
    @Override
    public UncompletedProfile create(String name, String description, CompletedProfile basic) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .POST(HttpHelper.jsonBodyPublisher(new HttpCreateProfileRequest(name, description, basic == null ? null : basic.getProfile())))
                            .uri(URI.create(baseUrl.concat("/profile/new")))
                            .header("Content-Type", "application/json")
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HttpUncompletedProfile.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow).thenCompose(result -> {
                        if(basic == null && result.profile == null) {
                            ClientProfile newClientProfile = new ClientProfileBuilder()
                                .setTitle(name)
                                .setInfo(description)
                                .setDir(name)
                                .setUuid(result.getUuid())
                                .createClientProfile();
                            return pushUpdateAsync(result, newClientProfile, null, null).thenApply(e -> result);
                        }
                        return CompletableFuture.completedFuture(result);
                    }).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(UncompletedProfile profile) {
        try {
            HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .DELETE()
                            .uri(URI.create(baseUrl.concat("/profile/by/uuid/"+profile.getUuid())))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(Void.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Set<UncompletedProfile> getProfiles(Client socketClient) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .GET()
                            .uri(URI.create(baseUrl.concat("/profile/list")))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(RequestFeatureHttpAPIImpl.HttpListProfilesResponse.class))
                    .thenApply(e -> e.getOrThrow().profiles().stream()
                            .map(es -> new HttpUncompletedProfile(es.getUUID(), es))
                            .map(x -> (UncompletedProfile) x)
                            .collect(Collectors.toSet()))
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public CompletedProfile pushUpdate(UncompletedProfile profile, String tag, ClientProfile clientProfile, List<ProfileAction> assetActions, List<ProfileAction> clientActions, List<UpdateFlag> flags) throws IOException {
        var prev = get(profile.getUuid(), tag);
        if(prev != null && prev.getProfile() != null && (prev.getProfile().getUUID() == null || !prev.getProfile().getUUID().equals(prev.getUuid()))) {
            clientProfile = new ClientProfileBuilder(clientProfile)
                    .setUuid(prev.getUuid())
                    .createClientProfile();
        }
        HashedDir clientDir = prev == null ? null : prev.getClientDir();
        HashedDir assetDir = prev == null ? null : prev.getAssetDir();
        if(flags.contains(UpdateFlag.USE_DEFAULT_ASSETS)) {
            assetDir = getUnconnectedDirectory("assets");
        }
        if(assetDir == null) {
            assetDir = new HashedDir();
        }
        if(clientDir == null) {
            clientDir = new HashedDir();
        }
        if(assetActions != null) {
            execute(assetDir, assetActions);
        }
        if(clientActions != null) {
            execute(clientDir, clientActions);
        }

        try {
            return pushUpdateAsync(profile, clientProfile, clientDir, assetDir).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    private CompletableFuture<HttpProfile> pushUpdateAsync(UncompletedProfile profile, ClientProfile clientProfile, HashedDir clientDir, HashedDir assetDir) {
        return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                        .POST(HttpHelper.jsonBodyPublisher(new HttpUpdateProfileRequest(clientProfile, clientDir, assetDir)))
                        .uri(URI.create(baseUrl.concat("/profile/by/uuid/" + profile.getUuid() + "/pushupdate")))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + accessToken)
                        .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HttpProfile.class))
                .thenApply(HttpHelper.HttpOptional::getOrThrow);
    }

    @Override
    public void download(CompletedProfile profile, Map<String, Path> files, boolean assets) throws IOException {
        HttpProfile httpProfile = (HttpProfile) profile;
        HashedDir dir;
        if(assets) {
            dir = httpProfile.assets;
        } else {
            dir = httpProfile.client;
        }
        List<Downloader.SizedFile> sizedFiles = new ArrayList<>();
        for(var e : files.entrySet()) {
            var key = e.getKey();
            var path = e.getValue();
            if(!key.isEmpty() && !key.equals(".")) {
                var ref = dir.tryFindRecursive(key);
                if(!ref.isFound()) {
                    throw new FileNotFoundException(key);
                }
                if(ref.entry instanceof HashedFile file) {
                    IOHelper.createParentDirs(path);
                    sizedFiles.add(new Downloader.SizedFile(file.url, path.toString(), file.size()));
                } else if(ref.entry instanceof HashedDir hdir) {
                    hdir.walk("/", (rpath, name, entry) -> {
                        if(entry instanceof HashedFile file) {
                            Path target = path.resolve(rpath);
                            try {
                                IOHelper.createParentDirs(target);
                            } catch (IOException ex) {
                                throw new RuntimeException(ex);
                            }
                            sizedFiles.add(new Downloader.SizedFile(file.url, target.toString(), file.size()));
                        }
                        return HashedDir.WalkAction.CONTINUE;
                    });
                }
            } else {
                dir.walk("/", (rpath, name, entry) -> {
                    if(entry instanceof HashedFile file) {
                        Path target = path.resolve(rpath);
                        try {
                            IOHelper.createParentDirs(target);
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                        sizedFiles.add(new Downloader.SizedFile(file.url, target.toString(), file.size()));
                    }
                    return HashedDir.WalkAction.CONTINUE;
                });
            }
        }
        log.info("Download {} files", sizedFiles.size());
        try {
            Command.downloadWithProgressBar("files", sizedFiles, "https://example.com", Path.of(""));
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    @Override
    public HashedDir getUnconnectedDirectory(String name) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .GET()
                            .uri(URI.create(baseUrl.concat("/profile/unconnected/"+name)))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HashedDir.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow)
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            return null;
        }
    }

    @Override
    public CompletedProfile get(UUID uuid, String tag) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .GET()
                            .uri(URI.create(baseUrl.concat("/profile/by/uuid/"+uuid)))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HttpProfile.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow)
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public CompletedProfile get(String name, String tag) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .GET()
                            .uri(URI.create(baseUrl.concat("/profile/by/name/"+name)))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HttpProfile.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow)
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public HttpFileUploadResponse uploadFile(HttpRequest.BodyPublisher bodyPublisher) {
        try {
            return HttpHelper.sendAsync(client, HttpRequest.newBuilder()
                            .POST(bodyPublisher)
                            .uri(URI.create(baseUrl.concat("/profile/uploadfile")))
                            .header("Authorization", "Bearer "+accessToken)
                            .build(), new RequestFeatureHttpAPIImpl.HttpErrorHandler<>(HttpFileUploadResponse.class))
                    .thenApply(HttpHelper.HttpOptional::getOrThrow).get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public void execute(HashedDir dir, List<ProfileAction> actions) throws IOException {
        for(var action : actions) {
            execute(dir, action);
        }
    }

    public void execute(HashedDir dir, ProfileAction action) throws IOException {
        switch (action.type()) {
            case UPLOAD -> {
                if(action.source() == null) {
                    var r = dir.createParentDirectories(action.target());
                    try(var output = new ByteArrayOutputStream()) {
                        try(var input = action.input().get()) {
                            input.transferTo(output);
                        }
                        byte[] bytes = output.toByteArray();
                        var res = uploadFile(HttpRequest.BodyPublishers.ofByteArray(bytes));
                        HashedFile file = new HashedFile(bytes, res.url());
                        r.parent.put(r.name, file);
                    }
                } else {
                    HashedDir srcDir = new HashedDir(Path.of(action.source()), null, true, true);
                    HashedDir.Diff diff = srcDir.diff(dir, null);
                    diff.mismatch.walk("/", (HashedDir.WalkCallback) (path, name, entry) -> {
                        if(entry.getType() == HashedEntry.Type.FILE) {
                            var r = dir.createParentDirectories(Path.of(action.target()).resolve(path).toString().replace('\\', '/'));
                            try(var output = new ByteArrayOutputStream()) {
                                try(var input = IOHelper.newInput(Path.of(action.source()).resolve(path))) {
                                    input.transferTo(output);
                                }
                                byte[] bytes = output.toByteArray();
                                var res = uploadFile(HttpRequest.BodyPublishers.ofByteArray(bytes));
                                HashedFile file = new HashedFile(bytes, res.url());
                                r.parent.put(name, file);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        return HashedDir.WalkAction.CONTINUE;
                    });
                }
            }
            case COPY -> {
                throw new UnsupportedOperationException();
            }
            case MOVE -> {
                throw new UnsupportedOperationException();
            }
            case DELETE -> {
                throw new UnsupportedOperationException();
            }
        }
    }

    public record HttpFileUploadResponse(String url) {

    }

    public record HttpCreateProfileRequest(String name, String description, ClientProfile profile) {

    }

    public record HttpUpdateProfileRequest(ClientProfile profile, HashedDir clientDir, HashedDir assetDir) {

    }

    public record HttpUncompletedProfile(UUID uuid, ClientProfile profile) implements UncompletedProfile {

        @Override
        public UUID getUuid() {
            return uuid;
        }

        @Override
        public String getName() {
            return profile.getName();
        }

        @Override
        public String getDescription() {
            return profile.getDescription();
        }

        @Override
        public String getDefaultTag() {
            return "";
        }
    }

    public record HttpProfile(ClientProfile profile, HashedDir client, HashedDir assets) implements CompletedProfile {

        @Override
        public String getTag() {
            return "";
        }

        @Override
        public ClientProfile getProfile() {
            return profile;
        }

        @Override
        public HashedDir getClientDir() {
            return client;
        }

        @Override
        public HashedDir getAssetDir() {
            return assets;
        }

        @Override
        public UUID getUuid() {
            return profile.getUUID();
        }

        @Override
        public String getName() {
            return profile.getName();
        }

        @Override
        public String getDescription() {
            return profile.getDescription();
        }

        @Override
        public String getDefaultTag() {
            return "";
        }
    }
}
